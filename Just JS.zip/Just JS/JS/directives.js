var app = angular.module('myapp',[]);

app.directive('calendarBody', function(){
	return {
		restrict: 'E',
		templateUrl: 'HTML/calendarBody.html'
	};
});